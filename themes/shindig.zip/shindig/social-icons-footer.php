<div class="social-ico">
	<?php if (get_theme_mod( 'footer_mail_link_progression' )) : ?><a href="<?php echo get_theme_mod('footer_mail_link_progression'); ?>" target="_blank"><i class="fa fa-envelope"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'footer_facebook_link_progression' )) : ?><a href="<?php echo get_theme_mod('footer_facebook_link_progression'); ?>" target="_blank"><i class="fa fa-facebook"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'footer_twitter_link_progression' )) : ?><a href="<?php echo get_theme_mod('footer_twitter_link_progression'); ?>" target="_blank"><i class="fa fa-twitter"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'footer_google_link_progression' )) : ?><a href="<?php echo get_theme_mod('footer_google_link_progression'); ?>" target="_blank"><i class="fa fa-google-plus"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'linkedin_link_progression' )) : ?><a href="<?php echo get_theme_mod('linkedin_link_progression'); ?>" target="_blank"><i class="fa fa-linkedin"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'instagram_link_progression' )) : ?><a href="<?php echo get_theme_mod('instagram_link_progression'); ?>" target="_blank"><i class="fa fa-instagram"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'footer_pinterest_link_progression' )) : ?><a href="<?php echo get_theme_mod('footer_pinterest_link_progression'); ?>" target="_blank"><i class="fa fa-pinterest"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'tumblr_link_progression' )) : ?><a href="<?php echo get_theme_mod('tumblr_link_progression'); ?>" target="_blank"><i class="fa fa-tumblr"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'youtube_link_progression' )) : ?><a href="<?php echo get_theme_mod('youtube_link_progression'); ?>" target="_blank"><i class="fa fa-youtube-play"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'dropbox_link_progression' )) : ?><a href="<?php echo get_theme_mod('dropbox_link_progression'); ?>" target="_blank"><i class="fa fa-dropbox"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'flickr_link_progression' )) : ?><a href="<?php echo get_theme_mod('flickr_link_progression'); ?>" target="_blank"><i class="fa fa-flickr"></i></a><?php endif; ?>
		<?php if (get_theme_mod( 'dribbble_link_progression' )) : ?><a href="<?php echo get_theme_mod('dribbble_link_progression'); ?>" target="_blank"><i class="fa fa-dribbble"></i></a><?php endif; ?>
</div>